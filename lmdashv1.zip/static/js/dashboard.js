function loadAlerts() {
    fetch('/api/dashboard/alerts')
        .then(r => r.json())
        .then(alerts => {
            const container = document.getElementById('alertsStream');
            container.innerHTML = '';
            
            alerts.forEach(alert => {
                const alertDiv = document.createElement('div');
                alertDiv.className = `alert-item ${alert.severity}`;
                alertDiv.innerHTML = `
                    <div class="alert-header">
                        <span class="alert-severity">${alert.severity.toUpperCase()}</span>
                        <span class="alert-time">${new Date(alert.created_at).toLocaleString()}</span>
                    </div>
                    <div class="alert-title">${alert.title}</div>
                    <div class="alert-description">${alert.description}</div>
                    <div class="alert-action">${alert.recommended_action}</div>
                `;
                container.appendChild(alertDiv);
            });
        });
}

loadAlerts();
setInterval(loadAlerts, 30000);
