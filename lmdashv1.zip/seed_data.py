from models import db, Policy, Claim, RiskScore, Alert, ExternalFeed
from datetime import datetime, timedelta
import random

def seed_database():
    """Generate synthetic insurance data"""
    
    industries = ['Construction', 'Manufacturing', 'Retail', 'Healthcare', 'Technology', 'Transportation', 'Real Estate']
    coverage_types = ['Property', 'Liability', 'Auto', 'Workers Comp', 'Professional Liability']
    claim_types = ['Property Damage', 'Bodily Injury', 'Theft', 'Fire', 'Water Damage', 'Storm', 'Collision']
    zip_codes = ['90210', '10001', '60601', '02101', '94102', '33139', '78701', '98101']
    
    lat_long = {
        '90210': (34.0901, -118.4065),
        '10001': (40.7506, -73.9971),
        '60601': (41.8856, -87.6215),
        '02101': (42.3554, -71.0640),
        '94102': (37.7796, -122.4193),
        '33139': (25.7825, -80.1310),
        '78701': (30.2747, -97.7403),
        '98101': (47.6131, -122.3426)
    }
    
    names = ['Acme Corp', 'Global Industries', 'Tech Solutions', 'Metro Services', 'Premier Group', 
             'Sunrise Ventures', 'Pacific Trading', 'Alliance Partners', 'Eagle Enterprises', 'Summit Holdings']
    
    policies = []
    for i in range(60):
        zip_code = random.choice(zip_codes)
        lat, lon = lat_long[zip_code]
        
        policy = Policy(
            policy_number=f'POL-2024-{1000 + i}',
            policyholder_name=f'{random.choice(names)} {random.choice(["LLC", "Inc", "Co"])}',
            industry=random.choice(industries),
            coverage_type=random.choice(coverage_types),
            coverage_amount=random.choice([500000, 1000000, 2000000, 5000000]),
            premium=random.randint(5000, 50000),
            deductible=random.choice([1000, 2500, 5000, 10000]),
            start_date=datetime.now() - timedelta(days=random.randint(30, 365)),  # Within last year
            end_date=datetime.now() + timedelta(days=random.randint(30, 365)),  # Future dates
            status='active' if random.random() > 0.1 else 'expired',
            zip_code=zip_code,
            latitude=lat + random.uniform(-0.1, 0.1),
            longitude=lon + random.uniform(-0.1, 0.1)
        )
        policies.append(policy)
        db.session.add(policy)
    
    db.session.commit()
    
    claims = []
    for policy in policies[:40]:
        num_claims = random.choices([0, 1, 2, 3, 4], weights=[30, 40, 20, 7, 3])[0]
        
        for j in range(num_claims):
            claim = Claim(
                claim_number=f'CLM-2024-{2000 + len(claims)}',
                policy_id=policy.id,
                claim_date=datetime.now() - timedelta(days=random.randint(1, 180)),  # Within last 6 months
                claim_amount=random.randint(1000, 100000),
                claim_type=random.choice(claim_types),
                description=f'{random.choice(claim_types)} incident at insured location',
                status=random.choice(['pending', 'approved', 'settled', 'rejected']),
                settlement_amount=random.randint(500, 80000) if random.random() > 0.3 else None,
                settlement_date=datetime.now() - timedelta(days=random.randint(1, 100)) if random.random() > 0.5 else None
            )
            claims.append(claim)
            db.session.add(claim)
    
    db.session.commit()
    
    for policy in policies:
        num_scores = random.randint(8, 15)
        for k in range(num_scores):
            base_risk = random.uniform(0.2, 0.8)
            claim_count = len([c for c in claims if c.policy_id == policy.id])
            
            if claim_count > 2:
                base_risk += 0.15
            
            # Create scores distributed over the last 60 days (much more recent dates)
            days_back = random.randint(1, 60)  # Evenly distribute across last 60 days
            
            risk_score = RiskScore(
                policy_id=policy.id,
                risk_score=min(base_risk, 0.95),
                score_date=datetime.now() - timedelta(days=days_back),
                claim_likelihood=random.uniform(0.1, 0.6),
                fraud_probability=random.uniform(0.05, 0.4),
                feature_contributions='{"claims": 0.3, "industry": 0.2, "coverage": 0.15}',
                model_version='v1.0'
            )
            db.session.add(risk_score)
    
    db.session.commit()
    
    alert_titles = [
        'High-risk policy requires review',
        'Emerging cluster in ZIP 90210',
        'Unusual claim pattern detected',
        'Premium adjustment recommended',
        'Fraud probability elevated',
        'Policy renewal approaching',
        'Loss ratio exceeds threshold',
        'Multiple claims in 30 days'
    ]
    
    for i in range(25):
        alert = Alert(
            title=random.choice(alert_titles),
            description=f'Automated alert generated based on risk assessment criteria. Policy or claim requires attention.',
            severity=random.choice(['low', 'medium', 'high', 'critical']),
            alert_type=random.choice(['risk', 'fraud', 'renewal', 'cluster']),
            related_entity=f'POL-2024-{random.randint(1000, 1059)}',
            recommended_action=random.choice([
                'Review policy details and adjust premium',
                'Assign to fraud investigation team',
                'Schedule underwriting review',
                'Contact policyholder for verification'
            ]),
            status='open' if random.random() > 0.3 else 'resolved',
            created_at=datetime.now() - timedelta(days=random.randint(0, 60))  # Within last 60 days
        )
        db.session.add(alert)
    
    db.session.commit()
    
    feed_types = ['weather_severity', 'crime_index', 'wildfire_risk', 'flood_risk']
    
    for zip_code in zip_codes:
        for feed_type in feed_types:
            for i in range(5):
                feed = ExternalFeed(
                    feed_type=feed_type,
                    zip_code=zip_code,
                    data_value=random.uniform(0, 10),
                    data_category=feed_type.split('_')[0],
                    timestamp=datetime.now() - timedelta(hours=i * 24),
                    feed_metadata=f'{{"source": "external_api", "confidence": {random.uniform(0.7, 0.99)}}}'
                )
                db.session.add(feed)
    
    db.session.commit()
    
    print(f'Database seeded with {len(policies)} policies, {len(claims)} claims, and 25 alerts')
