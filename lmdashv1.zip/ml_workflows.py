
from sklearn.ensemble import RandomForestClassifier
from models import Policy, Claim, RiskScore, ExternalFeed, db
from datetime import datetime, timedelta
import json

class RiskScorer:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=10, random_state=42)
        self.is_trained = False
    
    def calculate_risk_score(self, policy_id):
        policy = Policy.query.get(policy_id)
        if not policy:
            return 0.5, {}
        
        features = self._extract_features(policy)
        
        claim_count = Claim.query.filter_by(policy_id=policy_id).count()
        recent_claims = Claim.query.filter_by(policy_id=policy_id).filter(
            Claim.claim_date >= datetime.now() - timedelta(days=180)
        ).count()
        
        total_claim_amount = sum(
            c.claim_amount for c in Claim.query.filter_by(policy_id=policy_id).all()
        )
        
        risk_score = 0.3
        
        if claim_count > 2:
            risk_score += 0.2
        if recent_claims > 0:
            risk_score += 0.15 * recent_claims
        if total_claim_amount > policy.premium * 2:
            risk_score += 0.25
        if policy.coverage_amount > 1000000:
            risk_score += 0.1
        
        risk_score = min(risk_score, 0.99)
        
        return risk_score, features
    
    def _extract_features(self, policy):
        claims = Claim.query.filter_by(policy_id=policy.id).all()
        
        return {
            'claim_count': len(claims),
            'total_claim_amount': sum(c.claim_amount for c in claims),
            'coverage_amount': policy.coverage_amount,
            'premium': policy.premium,
            'deductible': policy.deductible,
            'policy_age_days': (datetime.now() - policy.start_date).days if policy.start_date else 0,
            'industry': policy.industry
        }

class FraudDetector:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=10, random_state=42)
    
    def predict_fraud_probability(self, policy_id):
        policy = Policy.query.get(policy_id)
        if not policy:
            return 0.1
        
        claims = Claim.query.filter_by(policy_id=policy_id).all()
        
        fraud_prob = 0.1
        
        if len(claims) > 3:
            fraud_prob += 0.2
        
        total_claim_amount = sum(c.claim_amount for c in claims)
        if total_claim_amount > policy.coverage_amount * 0.8:
            fraud_prob += 0.3
        
        recent_claims = [c for c in claims if (datetime.now() - c.claim_date).days < 90]
        if len(recent_claims) > 2:
            fraud_prob += 0.25
        
        fraud_prob = min(fraud_prob, 0.95)
        
        return fraud_prob

class FeatureExplainer:
    def explain_prediction(self, features, score):
        contributions = []
        
        if features.get('claim_count', 0) > 2:
            contributions.append({
                'feature': 'High claim frequency',
                'impact': 0.2,
                'description': f"{features['claim_count']} claims filed (30% of risk increase)"
            })
        
        if features.get('total_claim_amount', 0) > features.get('premium', 1) * 2:
            contributions.append({
                'feature': 'High claim to premium ratio',
                'impact': 0.25,
                'description': f"Total claims exceed 2x premium (25% of risk increase)"
            })
        
        if features.get('coverage_amount', 0) > 1000000:
            contributions.append({
                'feature': 'High coverage amount',
                'impact': 0.1,
                'description': f"Large exposure: ${features['coverage_amount']:,.0f} (10% of risk increase)"
            })
        
        contributions.sort(key=lambda x: x['impact'], reverse=True)
        
        return contributions[:3]
