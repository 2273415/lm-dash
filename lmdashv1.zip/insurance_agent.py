import sqlite3
import json
import requests
from datetime import datetime
import os
from dotenv import load_dotenv
import logging

load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load LLM API URL from environment variable
URL = os.getenv("LLM_API_URL", "https://ibhraxhp9j.execute-api.ap-south-1.amazonaws.com/dev/query")

# Get absolute path to database
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'instance', 'insurance.db')

# ==========================================
# 1. DATABASE UTILITIES
# ==========================================
def get_connection():
    """Returns a connection to the SQLite database."""
    logger.info(f"Connecting to database at: {DB_PATH}")
    if not os.path.exists(DB_PATH):
        logger.error(f"Database file not found at: {DB_PATH}")
    return sqlite3.connect(DB_PATH)

def get_schema_info():
    """Queries the database metadata to provide the LLM with table structures."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
        tables = cursor.fetchall()
        
        schema_details = []
        for table in tables:
            table_name = table[0]
            cursor.execute(f"PRAGMA table_info({table_name});")
            columns = cursor.fetchall()
            col_text = ", ".join([f"{c[1]} ({c[2]})" for c in columns])
            schema_details.append(f"Table: {table_name}\nColumns: {col_text}")
        
        conn.close()
        return "\n".join(schema_details)
    except Exception as e:
        return f"Error fetching schema: {str(e)}"

# ==========================================
# 2. THE INSURANCE AGENT
# ==========================================
class InsuranceAgent:
    def __init__(self):
        # Fetch schema once during initialization
        self.schema = get_schema_info()

    def llm_call(self, user_query: str) -> str:
        """Your specific requests-based LLM call."""
        payload = {"query": user_query}
        headers = {"Content-Type": "application/json"}
        
        try:
            response = requests.post(URL, data=json.dumps(payload), headers=headers)
            call = response.json()
            # Returns the 'response' field from your API
            return call.get('response', "none")
        except Exception as e:
            return f"Error: {str(e)}"

    def _get_system_prompt(self):
        return f"""You are a professional Insurance Data Analyst.
DB SCHEMA:
{self.schema}

STRICT SQL RULES:
1. Use ONLY SQLite-compatible syntax.
2. Output your logic under 'PLAN:' and the raw SQL under 'SQL:'.
3. DO NOT use markdown code blocks (```). Output raw text only."""

    def generate_sql_plan(self, user_input, chat_history):
        """Step 1: Planning and SQL Generation."""
        prompt = f"""{self._get_system_prompt()}
HISTORY: {chat_history}
USER TASK: "{user_input}"

OUTPUT FORMAT:
PLAN: [Reasoning]
SQL: [Raw SQLite Query]"""
        
        return self.llm_call(prompt).strip()

    def execute_sql(self, sql_query):
        """Step 2: Database Execution."""
        conn = get_connection()
        conn.row_factory = sqlite3.Row 
        cursor = conn.cursor()
        try:
            # Clean common LLM artifacts just in case
            sql_query = sql_query.replace("```sql", "").replace("```", "").strip()
            cursor.execute(sql_query)
            rows = cursor.fetchall()
            data = [dict(row) for row in rows]
            return {"data": data, "error": None}
        except Exception as e:
            return {"data": [], "error": str(e)}
        finally:
            conn.close()

    def summarize_results1(self, user_input, data_results):
        """Step 3: Data Summarization into a human-friendly answer."""
        prompt = f"""You are a professional insurance assistant. 
User Question: {user_input}
Database Data: {json.dumps(data_results)}

Based on the data, provide a concise and professional summary. 
If no results were found, suggest what the user should check for."""
        
        return self.llm_call(prompt)
    def summarize_results(self, user_input, data_results):
        """Step 3: Data Summarization - Refined to prevent 'No Results' text on success."""
        
        # Check if we actually have data
        has_data = len(data_results) > 0
        
        prompt = f"""You are a professional insurance assistant. 
User Question: {user_input}
Database Data: {json.dumps(data_results)}

INSTRUCTIONS:
1. If data is present, provide a concise, professional summary of the results in text not in tables.
2. If the data list is empty [], ONLY THEN explain that no results were found and suggest what they should check for.
3. Do not include 'No Results Found' sections if you have already provided data above."""
        
        return self.llm_call(prompt)
    def invoke(self, inputs):
        """Main Pipeline: Execute Task and Summarize."""
        user_message = inputs.get('input')
        chat_history = inputs.get('chat_history', [])

        # 1. Get Plan and SQL
        raw_output = self.generate_sql_plan(user_message, chat_history)
        
        # 2. Extract SQL part
        if "SQL:" in raw_output:
            sql_to_run = raw_output.split("SQL:")[-1].strip()
        else:
            sql_to_run = raw_output

        # 3. Execute against SQLite
        db_results = self.execute_sql(sql_to_run)

        # 4. Generate Conversational Summary
        if db_results["error"]:
            final_answer = f"I encountered an error querying the database: {db_results['error']}"
        else:
            final_answer = self.summarize_results(user_message, db_results["data"])

        return {
            'output': final_answer,
            'plan': raw_output,
            'raw_data': db_results["data"]
        }

# ==========================================
# 3. FACTORY FUNCTION
# ==========================================
def create_insurance_agent(unused_arg=None):
    """
    Factory function. 
    Matches your requested import style: 
    agent = create_insurance_agent(llm)
    """
    return InsuranceAgent()

# Example of how you would call this:
if __name__ == "__main__":
    agent = create_insurance_agent()
    response = agent.invoke({
        'input': 'Show me all pending claims',
        'chat_history': []
    })
    print(response['output'])
    print(response)