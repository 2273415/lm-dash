from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Policy(db.Model):
    __tablename__ = 'policies'
    
    id = db.Column(db.Integer, primary_key=True)
    policy_number = db.Column(db.String(50), unique=True, nullable=False)
    policyholder_name = db.Column(db.String(120), nullable=False)
    industry = db.Column(db.String(50))
    coverage_type = db.Column(db.String(50))
    coverage_amount = db.Column(db.Float)
    premium = db.Column(db.Float)
    deductible = db.Column(db.Float)
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='active')
    zip_code = db.Column(db.String(10))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    claims = db.relationship('Claim', backref='policy', lazy=True)
    risk_scores = db.relationship('RiskScore', backref='policy', lazy=True)
    
    def __repr__(self):
        return f'<Policy {self.policy_number}>'

class Claim(db.Model):
    __tablename__ = 'claims'
    
    id = db.Column(db.Integer, primary_key=True)
    claim_number = db.Column(db.String(50), unique=True, nullable=False)
    policy_id = db.Column(db.Integer, db.ForeignKey('policies.id'), nullable=False)
    claim_date = db.Column(db.DateTime, nullable=False)
    claim_amount = db.Column(db.Float)
    claim_type = db.Column(db.String(50))
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')
    settlement_amount = db.Column(db.Float)
    settlement_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Claim {self.claim_number}>'

class RiskScore(db.Model):
    __tablename__ = 'risk_scores'
    
    id = db.Column(db.Integer, primary_key=True)
    policy_id = db.Column(db.Integer, db.ForeignKey('policies.id'), nullable=False)
    risk_score = db.Column(db.Float, nullable=False)
    score_date = db.Column(db.DateTime, default=datetime.utcnow)
    claim_likelihood = db.Column(db.Float)
    fraud_probability = db.Column(db.Float)
    feature_contributions = db.Column(db.Text)
    model_version = db.Column(db.String(20))
    
    def __repr__(self):
        return f'<RiskScore {self.policy_id}: {self.risk_score}>'

class Alert(db.Model):
    __tablename__ = 'alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    severity = db.Column(db.String(20))
    alert_type = db.Column(db.String(50))
    related_entity = db.Column(db.String(50))
    recommended_action = db.Column(db.Text)
    status = db.Column(db.String(20), default='open')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<Alert {self.title}>'

class ExternalFeed(db.Model):
    __tablename__ = 'external_feeds'
    
    id = db.Column(db.Integer, primary_key=True)
    feed_type = db.Column(db.String(50))
    zip_code = db.Column(db.String(10))
    data_value = db.Column(db.Float)
    data_category = db.Column(db.String(50))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    feed_metadata = db.Column(db.Text)
    
    def __repr__(self):
        return f'<ExternalFeed {self.feed_type}>'
