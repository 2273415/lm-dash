
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_bcrypt import Bcrypt
import sqlite3
from werkzeug.utils import secure_filename
import zipfile
import json
from flask import Flask, request, jsonify
from utils.azure_process import Azure_pippeline
from utils.database_manage import init_db
import os
import ast
try:
  DB_PATH=r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\docintel_v1\database\operations.db"
  
except:
  DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'database', 'operations.db'))

ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'csv', 'xlsx', 'ppt', 'pptx', 'zip'])


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_text_before_numbers(s):
    result = ''
    for char in s:
        if char.isdigit():
            break
        result += char
    return result



app = Flask(__name__)
bcrypt = Bcrypt(app)
app.secret_key = 'mykey'




@app.route('/')
def index():
    if 'user_id' in session:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
        user = c.fetchone()
        conn.close()
        if user:
            email = user[0]
            username = email.split('@')[0] if '@' in email else email
            profile_initial = username[0].upper() if username else ''
            return render_template('home.html', username=username, email=email, profile_initial=profile_initial)
    return redirect(url_for('login'))

# ---------------- SIGNUP ----------------
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        print(username,password,confirm)
        if not username or not password:
            flash('Please provide both username and password.', 'error')
            return render_template('signup.html')

        if password != confirm:
            flash('Passwords do not match', 'error')
            return render_template('signup.html')

        hashed = bcrypt.generate_password_hash(password)

        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute(
                'INSERT INTO users (username, password, accepted_terms) VALUES (?, ?, ?)',
                (username, hashed, 0)
            )
            conn.commit()
            # verify insert
            c.execute('SELECT id FROM users WHERE username = ?', (username,))
            user_row = c.fetchone()
            conn.close()

            if not user_row:
                flash('An error occurred during signup. Please try again.', 'success')
                return render_template('signup.html')

            # set pending user in session for terms
            session['pending_user'] = username
            return redirect(url_for('terms'))

        except sqlite3.IntegrityError:
            flash('Username already exists.', 'error')
        except Exception as e:
            app.logger.error(f"Signup error: {str(e)}")
            flash('An error occurred during signup.', 'error')

    return render_template('signup.html')

# ---------------- TERMS ----------------
@app.route('/terms', methods=['GET', 'POST'])
def terms():
    username = session.get('pending_user')
    if not username:
        flash("You must sign up first before accepting terms.", "error")
        return redirect(url_for('signup'))

    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'accept':
            try:
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute('UPDATE users SET accepted_terms = 1 WHERE username = ?', (username,))
                conn.commit()
                conn.close()

                session.pop('pending_user', None)
                flash("You’ve accepted the Terms and Conditions. Please log in.", "message")
                return redirect(url_for('login'))

            except Exception as e:
                app.logger.error(f"Terms acceptance error for {username}: {str(e)}")
                flash("An error occurred while saving your acceptance.", "error")

        elif action == 'decline':
            try:
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute('DELETE FROM users WHERE username = ?', (username,))
                conn.commit()
                conn.close()

                session.pop('pending_user', None)
                flash("You declined the Terms. Please sign up again if you change your mind.", "error")
                return redirect(url_for('signup'))

            except Exception as e:
                app.logger.error(f"Decline deletion error for {username}: {str(e)}")
                flash("An error occurred while declining.", "error")

    return render_template('terms.html')

# ---------------- LOGIN ----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute('SELECT id, password, accepted_terms FROM users WHERE username = ?', (username,))
            user = c.fetchone()
            conn.close()

            if user and bcrypt.check_password_hash(user[1], password):
                accepted_terms = bool(user[2])
                if not accepted_terms:
                    # redirect to terms if not accepted
                    session['pending_user'] = username
                    flash('Please accept the Terms & Conditions before logging in.', 'warning')
                    return redirect(url_for('terms'))

                # login success
                session['user_id'] = user[0]
                return redirect(url_for('index'))

            flash('Invalid username or password.', 'error')

        except Exception as e:
            app.logger.error(f"Login error: {str(e)}")
            flash('An error occurred during login.', 'error')

    return render_template('login.html')
#____________________logout___________________
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))
#__________________about_______________________
@app.route('/about')
def about():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # You can pass username/profile if you want
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()
    conn.close()
    
    profile_initial = user[0][0].upper() if user else 'U'
    
    return render_template('about.html', profile_initial=profile_initial)
#_____________________________search_____________________
@app.route("/process", methods=["GET"])
def process_tab():
    if 'user_id' not in session:
        return redirect(url_for("login"))

    # Get current user
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()
    conn.close()

    if not user:
        return redirect(url_for("login"))

    username = user[0]  # exact username stored in DB
    profile_initial = username[0].upper() if username else 'U'

    # Get search query
    search_query = request.args.get('search', '').strip()

    # Query recent jobs for this user, case-insensitive filename search
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    if search_query:
        c.execute("""
            SELECT jobid, category, filename, document_type, job_creation_time,job_creation_date
            FROM jobs
            WHERE username = ? AND filename LIKE ? COLLATE NOCASE
            ORDER BY job_creation_time DESC
        """, (username, f"%{search_query}%"))
    else:
        c.execute("""
            SELECT jobid, category, filename, document_type, job_creation_time,job_creation_date
            FROM jobs
            WHERE username = ?
            ORDER BY job_creation_time DESC
        """, (username,))
    jobs = c.fetchall()
    print(jobs)
    conn.close()

    return render_template(
        "process.html",
        profile_initial=profile_initial,
        jobs=jobs,
        search_query=search_query
    )

#_________________________________job page________________________________
@app.route("/view/<jobid>")
def view_job(jobid):

    if 'user_id' not in session:
        return redirect(url_for("login"))

    # Get current user
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()
    conn.close()

    if not user:
        return redirect(url_for("login"))

    username = user[0]  # exact username stored in DB
    profile_initial = username[0].upper() if username else 'U'
    if 'user_id' not in session:
        return redirect(url_for("login"))

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    # Fetch job details by jobid
    c.execute("""SELECT filename, document_type, created, size_kb, extracted_text_output, 
                        category, category_confidence, extracted_data_json 
                 FROM jobs WHERE jobid = ?""", (jobid,))
    job = c.fetchone()
    conn.close()
    print("Raw JSON:", job[7])

    if not job:
        return "Job not found", 404

    # Parse JSON for table display
    extracted_data_dict = {}
    if job[7]:
        
        try:
                print("job7", job[7], "type", type(job[7]))
                
                # If job[7] is a string with single quotes, convert it to a Python dict first
                if isinstance(job[7], str):
                    extracted_data_dict = ast.literal_eval(job[7])  # safer than eval
                else:
                    extracted_data_dict = job[7]  # already a dict

                print("extracted files = ", extracted_data_dict)
        except Exception as e:
                print(f"there is a error ", e)


    return render_template("view_job.html", job=job, extracted_data=extracted_data_dict, profile_initial=profile_initial)

#_______________________________update option ___________________________
@app.route("/update_job/<jobid>", methods=["POST"])
def update_job(jobid):
    if 'user_id' not in session:
        return {"error": "Unauthorized"}, 401

    # Get the edited data from the frontend
    edited_data = request.get_json()
    if not edited_data:
        return {"error": "No data provided"}, 400

    # Convert dict to JSON string
    edited_json_str = json.dumps(edited_data)

    # Update the jobs table
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "UPDATE jobs SET extracted_data_json = ? WHERE jobid = ?",
        (edited_json_str, jobid)
    )
    conn.commit()
    conn.close()

    return {"message": "Job data updated successfully!"}, 200



@app.route('/proceed', methods=['POST'])
def proceed():
    # start pipeline for selected files
    selected = request.form.getlist('selected_files')
    if not selected:
        flash('No files selected to proceed', 'error')
        return redirect(url_for('index'))

    upload_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'uploads'))
    paths = [os.path.join(upload_dir, secure_filename(name)) for name in selected]

    # Get username from session in request context BEFORE starting thread
    username = None
    if 'user_id' in session:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
        user = c.fetchone()
        conn.close()
        if user:
            username = user[0]
              
        for path in paths:
            try:
                try:
                    if isinstance(path,list):
                        extraction= Azure_pippeline(path, username)

                    elif  isinstance (path,str) and path.split(".")[-1] == "zip":
                        extraction= Azure_pippeline(path, username)
                    else:
                        extraction=  Azure_pippeline([path], username)
                    return jsonify({"status": "Pipeline executed successfully","Extracted_json":f"{extraction}"}), 200
                except Exception as e:
                    return jsonify({"error": str(e)}), 500

            except Exception:
                app.logger.exception('Unexpected error during pipeline run')
    flash('Pipeline started for selected files', 'success')
    return redirect(url_for('index', process='completed'))


#_________________________delete account___________________________
@app.route("/delete-account", methods=["POST"])
def delete_account():
    if 'user_id' not in session:
        return {"error": "Unauthorized"}, 401

    user_id = session['user_id']

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    try:
        # Get username first
        c.execute("SELECT username FROM users WHERE id = ?", (user_id,))
        username = c.fetchone()
        if not username:
            return {"error": "User not found"}, 404
        
        username = username[0]

        # Delete all jobs belonging to the user
        c.execute("DELETE FROM jobs WHERE username = ?", (username,))
        
        # Delete the user
        c.execute("DELETE FROM users WHERE id = ?", (user_id,))
        
        conn.commit()
        
        # Clear the session
        session.clear()
        
        return {"message": "Account deleted successfully"}, 200
    except Exception as e:
        conn.rollback()
        return {"error": str(e)}, 500
    finally:
        conn.close()


##################process


@app.route('/upload_files', methods=['POST'])
def upload_files():
    if 'files' not in request.files:
        flash('No files part', 'error')
        return redirect(url_for('index'))
    files = request.files.getlist('files')
    file_infos = []
    # ensure uploads directory
    upload_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'uploads'))
    os.makedirs(upload_dir, exist_ok=True)
    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            save_path = os.path.join(upload_dir, filename)
            try:
                file.save(save_path)
                size = os.path.getsize(save_path)
            except Exception:
                # fallback to stream size
                file.seek(0, 2)
                size = file.tell()
                file.seek(0)
            file_infos.append({'filename': filename, 'filesize': f"{size/1024:.2f} KB", 'saved_name': filename})
        # If file is a zip, extract and list its contents
        elif file and file.filename.lower().endswith('.zip'):
            try:
                zip_name = secure_filename(file.filename)
                zip_path = os.path.join(upload_dir, zip_name)
                file.save(zip_path)
                with zipfile.ZipFile(zip_path) as z:
                    for info in z.infolist():
                        if not info.is_dir():
                            # extract into upload_dir
                            try:
                                z.extract(info, path=upload_dir)
                                extracted_basename = os.path.basename(info.filename)
                                file_infos.append({'filename': extracted_basename, 'filesize': f"{info.file_size/1024:.2f} KB", 'saved_name': extracted_basename})
                            except Exception:
                                continue
                try:
                    os.remove(zip_path)
                except Exception:
                    pass
            except Exception as e:
                flash(f'Error processing zip file: {file.filename}', 'error')
                continue
    if not file_infos:
        flash('No valid files uploaded', 'error')
        return redirect(url_for('index'))
    # remember uploaded filenames in session so proceed can find them
    try:
        session['uploaded_files'] = [f['saved_name'] for f in file_infos if 'saved_name' in f]
    except Exception:
        session['uploaded_files'] = []

    # If request came from AJAX (fetch), return a fragment suitable for injection
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return render_template('uploaded_files_fragment.html', files=file_infos)


# Upload zip file route
@app.route('/upload_zip', methods=['POST'])
def upload_zip():
    zipfile_obj = request.files.get('zipfile')
    if not zipfile_obj or not zipfile_obj.filename.lower().endswith('.zip'):
        flash('Please upload a valid zip file', 'error')
        return redirect(url_for('index'))
    file_infos = []
    with zipfile.ZipFile(zipfile_obj) as z:
        for info in z.infolist():
            if not info.is_dir():
                file_infos.append({'filename': info.filename, 'filesize': f"{info.file_size/1024:.2f} KB"})
    if not file_infos:
        flash('No files found in zip', 'error')
        return redirect(url_for('index'))
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return render_template('uploaded_files_fragment.html', files=file_infos)
    return render_template('uploaded_files.html', files=file_infos)




# #________________________azure_________________________
# @app.route('/azure_pipeline', methods=['POST'])
# def run_pipeline():
#     data = request.get_json()
#     path = data.get('path')
#     username = data.get('username')

#     if not path or not username:
#         return jsonify({"error": "Missing 'path' or 'username'"}), 400

#     try:
#         if isinstance(path,list):
#            extraction= Azure_pippeline(path, username)

#         elif  isinstance (path,str) and path.split(".")[-1] == "zip":
#             extraction= Azure_pippeline(path, username)
#         else:
#            extraction=  Azure_pippeline([path], username)
#         return jsonify({"status": "Pipeline executed successfully","Extracted_json":f"{extraction}"}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500




if __name__ == '__main__':
    init_db()
    app.run(debug=True)
