from typing import Optional
from pydantic import BaseModel

# --------------------- FINANCIAL & TRANSACTIONAL ---------------------
class Invoice(BaseModel):
    invoice_number: Optional[str]
    invoice_date: Optional[str]
    vendor_name: Optional[str]
    billing_address: Optional[str]
    total_amount: Optional[float]
    tax_amount: Optional[float]
    due_date: Optional[str]
    payment_terms: Optional[str]

class Receipt(BaseModel):
    receipt_number: Optional[str]
    date: Optional[str]
    payer_name: Optional[str]
    amount_paid: Optional[float]
    payment_method: Optional[str]
    vendor_name: Optional[str]

class Payslip(BaseModel):
    employee_name: Optional[str]
    employee_id: Optional[str]
    pay_period: Optional[str]
    basic_salary: Optional[float]
    allowances: Optional[float]
    deductions: Optional[float]
    net_pay: Optional[float]
    company_name: Optional[str]

class BankStatement(BaseModel):
    account_number: Optional[str]
    account_holder_name: Optional[str]
    statement_period: Optional[str]
    transaction_date: Optional[str]
    transaction_description: Optional[str]
    debit: Optional[float]
    credit: Optional[float]
    balance: Optional[float]

class TaxDocument(BaseModel):
    form_type: Optional[str]
    tax_year: Optional[str]
    taxpayer_name: Optional[str]
    PAN_number: Optional[str]
    income_details: Optional[str]
    deductions: Optional[float]
    tax_paid: Optional[float]
    refund_amount: Optional[float]

class PurchaseOrder(BaseModel):
    PO_number: Optional[str]
    PO_date: Optional[str]
    buyer_name: Optional[str]
    supplier_name: Optional[str]
    item_description: Optional[str]
    quantity: Optional[float]
    unit_price: Optional[float]
    total_amount: Optional[float]

class Quotation(BaseModel):
    quotation_number: Optional[str]
    date: Optional[str]
    vendor_name: Optional[str]
    item_description: Optional[str]
    unit_price: Optional[float]
    valid_until: Optional[str]
    terms_and_conditions: Optional[str]

class CreditNote(BaseModel):
    credit_note_number: Optional[str]
    date: Optional[str]
    customer_name: Optional[str]
    original_invoice_number: Optional[str]
    amount: Optional[float]
    reason: Optional[str]

class DebitNote(BaseModel):
    debit_note_number: Optional[str]
    date: Optional[str]
    vendor_name: Optional[str]
    related_invoice_number: Optional[str]
    amount: Optional[float]
    reason: Optional[str]

# --------------------- MEDICAL & HEALTH ---------------------
class MedicalBill(BaseModel):
    bill_number: Optional[str]
    hospital_name: Optional[str]
    patient_name: Optional[str]
    treatment_date: Optional[str]
    total_amount: Optional[float]
    insurance_coverage: Optional[str]
    doctor_name: Optional[str]

class Prescription(BaseModel):
    prescription_id: Optional[str]
    patient_name: Optional[str]
    doctor_name: Optional[str]
    date: Optional[str]
    medications: Optional[str]
    dosage: Optional[str]
    instructions: Optional[str]

class MedicalCertificate(BaseModel):
    certificate_number: Optional[str]
    patient_name: Optional[str]
    issue_date: Optional[str]
    doctor_name: Optional[str]
    validity_period: Optional[str]
    reason_for_leave: Optional[str]

class DischargeSummary(BaseModel):
    patient_name: Optional[str]
    hospital_name: Optional[str]
    admission_date: Optional[str]
    discharge_date: Optional[str]
    diagnosis: Optional[str]
    treatment_summary: Optional[str]
    doctor_name: Optional[str]

class LabReport(BaseModel):
    report_id: Optional[str]
    patient_name: Optional[str]
    test_name: Optional[str]
    test_date: Optional[str]
    result: Optional[str]
    normal_range: Optional[str]
    lab_name: Optional[str]

class InsuranceClaimForm(BaseModel):
    claim_number: Optional[str]
    policy_number: Optional[str]
    insured_name: Optional[str]
    hospital_name: Optional[str]
    treatment_date: Optional[str]
    claim_amount: Optional[float]
    diagnosis: Optional[str]

# --------------------- EMPLOYMENT & HR ---------------------
class OfferLetter(BaseModel):
    candidate_name: Optional[str]
    position: Optional[str]
    joining_date: Optional[str]
    salary: Optional[float]
    company_name: Optional[str]
    location: Optional[str]
    signatory: Optional[str]

class AppointmentLetter(BaseModel):
    employee_name: Optional[str]
    designation: Optional[str]
    joining_date: Optional[str]
    employee_id: Optional[str]
    department: Optional[str]
    terms_and_conditions: Optional[str]

class ExperienceCertificate(BaseModel):
    employee_name: Optional[str]
    designation: Optional[str]
    employment_period: Optional[str]
    company_name: Optional[str]
    issue_date: Optional[str]

class WorkPermit(BaseModel):
    permit_number: Optional[str]
    worker_name: Optional[str]
    nationality: Optional[str]
    employer_name: Optional[str]
    validity_period: Optional[str]
    work_sector: Optional[str]

class ResignationLetter(BaseModel):
    employee_name: Optional[str]
    resignation_date: Optional[str]
    last_working_day: Optional[str]
    reason: Optional[str]
    signature: Optional[str]

class PFForm(BaseModel):
    form_number: Optional[str]
    employee_name: Optional[str]
    PF_account_number: Optional[str]
    employer_name: Optional[str]
    submission_date: Optional[str]

class WageVoucher(BaseModel):
    employee_name: Optional[str]
    month: Optional[str]
    basic_salary: Optional[float]
    overtime: Optional[float]
    deductions: Optional[float]
    net_salary: Optional[float]

# --------------------- LEGAL & GOVERNMENT ---------------------
class IdentificationDocument(BaseModel):
    document_type: Optional[str]
    full_name: Optional[str]
    date_of_birth: Optional[str]
    nationality: Optional[str]
    document_number: Optional[str]
    expiry_date: Optional[str]

class BirthCertificate(BaseModel):
    child_name: Optional[str]
    date_of_birth: Optional[str]
    place_of_birth: Optional[str]
    parent_names: Optional[str]
    certificate_number: Optional[str]
    issuing_authority: Optional[str]

class DeathCertificate(BaseModel):
    deceased_name: Optional[str]
    date_of_death: Optional[str]
    cause_of_death: Optional[str]
    place_of_death: Optional[str]
    certificate_number: Optional[str]
    issued_by: Optional[str]

class MarriageCertificate(BaseModel):
    spouse_1_name: Optional[str]
    spouse_2_name: Optional[str]
    marriage_date: Optional[str]
    place_of_marriage: Optional[str]
    certificate_number: Optional[str]
    issued_by: Optional[str]

class Affidavit(BaseModel):
    affidavit_type: Optional[str]
    declarant_name: Optional[str]
    date: Optional[str]
    statement: Optional[str]
    witness_name: Optional[str]
    notary_details: Optional[str]

class CourtOrder(BaseModel):
    case_number: Optional[str]
    court_name: Optional[str]
    judge_name: Optional[str]
    order_date: Optional[str]
    parties_involved: Optional[str]
    order_summary: Optional[str]

class SubcontractorAgreement(BaseModel):
    contractor_name: Optional[str]
    subcontractor_name: Optional[str]
    agreement_date: Optional[str]
    scope_of_work: Optional[str]
    duration: Optional[str]
    signatories: Optional[str]

class WorkInjuryCompensationInsurance(BaseModel):
    policy_number: Optional[str]
    insured_name: Optional[str]
    coverage_details: Optional[str]
    insurance_provider: Optional[str]
    validity_period: Optional[str]

# --------------------- FORMS & REPORTS ---------------------
class ClaimForm(BaseModel):
    claim_number: Optional[str]
    policyholder_name: Optional[str]
    accident_date: Optional[str]
    claim_amount: Optional[float]
    insurance_provider: Optional[str]
    claim_status: Optional[str]

class IncidentReport(BaseModel):
    report_number: Optional[str]
    incident_date: Optional[str]
    location: Optional[str]
    description: Optional[str]
    witnesses: Optional[str]
    reported_by: Optional[str]

class ApplicationForm(BaseModel):
    form_type: Optional[str]
    applicant_name: Optional[str]
    date_of_birth: Optional[str]
    contact_details: Optional[str]
    submission_date: Optional[str]

class FeedbackForm(BaseModel):
    form_id: Optional[str]
    respondent_name: Optional[str]
    date: Optional[str]
    feedback_text: Optional[str]
    rating: Optional[float]

class SurveyForm(BaseModel):
    survey_id: Optional[str]
    respondent_name: Optional[str]
    date: Optional[str]
    questions: Optional[str]
    responses: Optional[str]

class AuditReport(BaseModel):
    report_id: Optional[str]
    auditor_name: Optional[str]
    audit_date: Optional[str]
    scope: Optional[str]
    findings: Optional[str]
    recommendations: Optional[str]

class InspectionReport(BaseModel):
    report_id: Optional[str]
    inspector_name: Optional[str]
    inspection_date: Optional[str]
    location: Optional[str]
    observations: Optional[str]
    compliance_status: Optional[str]

# --------------------- EDUCATION & ACADEMIC ---------------------
class Marksheet(BaseModel):
    student_name: Optional[str]
    roll_number: Optional[str]
    exam_name: Optional[str]
    subjects: Optional[str]
    grades: Optional[str]
    total_marks: Optional[float]
    result_status: Optional[str]

class DegreeCertificate(BaseModel):
    student_name: Optional[str]
    degree_name: Optional[str]
    university_name: Optional[str]
    graduation_date: Optional[str]
    certificate_number: Optional[str]

class BonafideCertificate(BaseModel):
    student_name: Optional[str]
    course_name: Optional[str]
    duration: Optional[str]
    institution_name: Optional[str]
    issue_date: Optional[str]

class AdmissionLetter(BaseModel):
    student_name: Optional[str]
    course_name: Optional[str]
    admission_date: Optional[str]
    institution_name: Optional[str]
    reference_number: Optional[str]

class FeeReceipt(BaseModel):
    receipt_number: Optional[str]
    student_name: Optional[str]
    course_name: Optional[str]
    amount_paid: Optional[float]
    payment_date: Optional[str]
    payment_mode: Optional[str]

# --------------------- LOGISTICS & OPERATIONS ---------------------
class DeliveryNote(BaseModel):
    delivery_note_number: Optional[str]
    date: Optional[str]
    recipient_name: Optional[str]
    items_delivered: Optional[str]
    quantity: Optional[float]
    delivery_address: Optional[str]

class PackingList(BaseModel):
    packing_list_number: Optional[str]
    shipment_date: Optional[str]
    items: Optional[str]
    quantity: Optional[float]
    weight: Optional[float]
    dimensions: Optional[str]

class ShippingLabel(BaseModel):
    tracking_number: Optional[str]
    sender_address: Optional[str]
    recipient_address: Optional[str]
    carrier_name: Optional[str]
    shipment_date: Optional[str]

class BillOfLading(BaseModel):
    BOL_number: Optional[str]
    shipper_name: Optional[str]
    consignee_name: Optional[str]
    vessel_name: Optional[str]
    port_of_loading: Optional[str]
    port_of_discharge: Optional[str]
    cargo_description: Optional[str]

# --------------------- INTELLECTUAL PROPERTY & BUSINESS ---------------------
class PatentDocument(BaseModel):
    patent_number: Optional[str]
    title: Optional[str]
    inventor_name: Optional[str]
    filing_date: Optional[str]
    grant_date: Optional[str]
    assignee: Optional[str]

class TrademarkCertificate(BaseModel):
    trademark_number: Optional[str]
    mark_name: Optional[str]
    owner_name: Optional[str]
    registration_date: Optional[str]
    validity_period: Optional[str]

class CopyrightRegistration(BaseModel):
    registration_number: Optional[str]
    work_title: Optional[str]
    author_name: Optional[str]
    registration_date: Optional[str]
    type_of_work: Optional[str]

class BusinessLicense(BaseModel):
    license_number: Optional[str]
    business_name: Optional[str]
    owner_name: Optional[str]
    issue_date: Optional[str]
    expiry_date: Optional[str]
    license_type: Optional[str]

class MoU(BaseModel):
    parties_involved: Optional[str]
    agreement_date: Optional[str]
    purpose: Optional[str]
    duration: Optional[str]
    signatories: Optional[str]

class NDA(BaseModel):
    parties_involved: Optional[str]
    effective_date: Optional[str]
    confidentiality_terms: Optional[str]
    duration: Optional[str]
    signatories: Optional[str]

class BoardResolution(BaseModel):
    resolution_number: Optional[str]
    meeting_date: Optional[str]
    board_members: Optional[str]
    resolution_text: Optional[str]
    signatories: Optional[str]

class CompanyIncorporationCertificate(BaseModel):
    company_name: Optional[str]
    incorporation_number: Optional[str]
    date_of_incorporation: Optional[str]
    registered_address: Optional[str]
    director_names: Optional[str]

class AnnualReport(BaseModel):
    company_name: Optional[str]
    fiscal_year: Optional[str]
    financial_summary: Optional[str]
    board_comments: Optional[str]
    auditor_report: Optional[str]

# --------------------- ENGINEERING & TECHNICAL ---------------------
class Blueprint(BaseModel):
    drawing_number: Optional[str]
    project_name: Optional[str]
    designer_name: Optional[str]
    revision_date: Optional[str]
    scale: Optional[str]
    dimensions: Optional[str]

class TechnicalSpecificationSheet(BaseModel):
    spec_id: Optional[str]
    product_name: Optional[str]
    parameters: Optional[str]
    tolerances: Optional[str]
    material: Optional[str]
    manufacturer: Optional[str]

class BillOfMaterials(BaseModel):
    BoM_id: Optional[str]
    product_name: Optional[str]
    components: Optional[str]
    quantity: Optional[float]
    unit: Optional[str]
    supplier: Optional[str]

class MaintenanceLog(BaseModel):
    log_id: Optional[str]
    equipment_name: Optional[str]
    maintenance_date: Optional[str]
    technician_name: Optional[str]
    issues_found: Optional[str]
    actions_taken: Optional[str]

class TestReport(BaseModel):
    report_id: Optional[str]
    test_type: Optional[str]
    test_date: Optional[str]
    equipment_name: Optional[str]
    results: Optional[str]
    conclusion: Optional[str]

class CalibrationCertificate(BaseModel):
    certificate_number: Optional[str]
    instrument_name: Optional[str]
    calibration_date: Optional[str]
    valid_until: Optional[str]
    technician_name: Optional[str]

class SOP(BaseModel):
    procedure_id: Optional[str]
    title: Optional[str]
    department: Optional[str]
    steps: Optional[str]
    safety_precautions: Optional[str]
    revision_date: Optional[str]

# --------------------- PROCUREMENT & VENDOR ---------------------
class VendorRegistrationForm(BaseModel):
    vendor_name: Optional[str]
    registration_number: Optional[str]
    contact_details: Optional[str]
    bank_details: Optional[str]
    approval_status: Optional[str]

class SupplierAgreement(BaseModel):
    supplier_name: Optional[str]
    agreement_date: Optional[str]

# --------------------- MAPPING ---------------------
MODEL_MAPPING = {
    # Financial & Transactional
    "Invoice": Invoice,
    "Receipt": Receipt,
    "Payslip": Payslip,
    "Bank Statement": BankStatement,
    "Tax Document": TaxDocument,
    "Purchase Order": PurchaseOrder,
    "Quotation": Quotation,
    "Credit Note": CreditNote,
    "Debit Note": DebitNote,

    # Medical & Health
    "Medical Bill": MedicalBill,
    "Prescription": Prescription,
    "Medical Certificate": MedicalCertificate,
    "Discharge Summary": DischargeSummary,
    "Lab Report": LabReport,
    "Insurance Claim Form": InsuranceClaimForm,

    # Employment & HR
    "Offer Letter": OfferLetter,
    "Appointment Letter": AppointmentLetter,
    "Experience Certificate": ExperienceCertificate,
    "Work Permit": WorkPermit,
    "Resignation Letter": ResignationLetter,
    "PF Form": PFForm,
    "Wage Voucher": WageVoucher,

    # Legal & Government
    "Identification Document": IdentificationDocument,
    "Birth Certificate": BirthCertificate,
    "Death Certificate": DeathCertificate,
    "Marriage Certificate": MarriageCertificate,
    "Affidavit": Affidavit,
    "Court Order": CourtOrder,
    "Sub-contractor Agreement": SubcontractorAgreement,
    "Work Injury Compensation Insurance": WorkInjuryCompensationInsurance,

    # Forms & Reports
    "Claim Form": ClaimForm,
    "Incident Report": IncidentReport,
    "Application Form": ApplicationForm,
    "Feedback Form": FeedbackForm,
    "Survey Form": SurveyForm,
    "Audit Report": AuditReport,
    "Inspection Report": InspectionReport,

    # Education & Academic
    "Marksheet": Marksheet,
    "Degree Certificate": DegreeCertificate,
    "Bonafide Certificate": BonafideCertificate,
    "Admission Letter": AdmissionLetter,
    "Fee Receipt": FeeReceipt,

    # Logistics & Operations
    "Delivery Note": DeliveryNote,
    "Packing List": PackingList,
    "Shipping Label": ShippingLabel,
    "Bill of Lading": BillOfLading,

    # Intellectual Property & Business
    "Patent Document": PatentDocument,
    "Trademark Certificate": TrademarkCertificate,
    "Copyright Registration": CopyrightRegistration,
    "Business License": BusinessLicense,
    "MoU": MoU,
    "NDA": NDA,
    "Board Resolution": BoardResolution,
    "Company Incorporation Certificate": CompanyIncorporationCertificate,
    "Annual Report": AnnualReport,

    # Engineering & Technical
    "Blueprint": Blueprint,
    "Technical Specification Sheet": TechnicalSpecificationSheet,
    "Bill of Materials": BillOfMaterials,
    "Maintenance Log": MaintenanceLog,
    "Test Report": TestReport,
    "Calibration Certificate": CalibrationCertificate,
    "SOP": SOP,

    # Procurement & Vendor
    "Vendor Registration Form": VendorRegistrationForm,
    "Supplier Agreement": SupplierAgreement
}
