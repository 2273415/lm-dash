
import sqlite3

###############################################################
DB_PATH = r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\docintel_v1\database\operations.db"
###############################################################



def init_db():
    try:
        conn = sqlite3.connect(DB_PATH)
    except Exception as db_error:
        print(f"Database error: {db_error}")
        
    try:   
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(100) NOT NULL,
                accepted_terms INTEGER DEFAULT 0 NOT NULL
            )''')
        # Add jobs table with improved columns
        c.execute('''CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            jobid TEXT NOT NULL,
            Job_creation_date VARCHAR(50),
            job_creation_time VARCHAR(50),
            username VARCHAR(50),
            filename VARCHAR(255) NOT NULL,
            document_type VARCHAR(50),
            created VARCHAR(50),
            size_kb REAL,
            extracted_text_output TEXT,
            category VARCHAR(100),
            category_confidence REAL,
            extracted_data_json TEXT
        )''')
        conn.commit()
        conn.close()
    except Exception as db_error:
        print(f"Database error: {db_error}")


def job_insert(jobid, job_creation_date, job_creation_time, username,
                filename, document_type, created, size_kb,
                extracted_text_output, category, category_confidence, extracted_data_json):
    try:
        conn = sqlite3.connect(DB_PATH)
    except Exception as db_error:
        print(f"Database error: {db_error}")
    try:
            
        c = conn.cursor()

        c.execute('''
            INSERT INTO jobs (
                jobid, job_creation_date, job_creation_time, username,
                filename, document_type, created, size_kb,
                extracted_text_output, category, category_confidence, extracted_data_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            jobid, job_creation_date, job_creation_time, username,
            filename, document_type, created, size_kb,
            extracted_text_output, category, category_confidence, str(extracted_data_json)
        ))
        conn.commit()
        conn.close()
    except Exception as db_error:
        print(f"Database error: {db_error}")
        conn.close()




