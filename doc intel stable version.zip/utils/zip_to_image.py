import pdfplumber
import io
from PIL import Image
# from docx2pdf import convert
from time import perf_counter
import zipfile, os, base64, tempfile, uuid
from datetime import datetime
import warnings
from typing import Union,List


warnings.filterwarnings("ignore")

def zip_to_images(zip_file):
    START = perf_counter()
    zip_data = {}
    all_images = []

    zip_ref = zipfile.ZipFile(zip_file if isinstance(zip_file, str) else zip_file, 'r')
    total_files = len([info for info in zip_ref.infolist() if not info.is_dir()])

    for info in zip_ref.infolist():
        if info.is_dir():
            continue

        filename = os.path.basename(info.filename)
        ext = os.path.splitext(info.filename)[1].lower()
        file_bytes = zip_ref.read(info.filename)

        page_images = []
        metadata = {
            "file_type": ext.replace(".", "").upper(),
            "size_kb": round(info.file_size / 1024, 2),
            "modified_date": datetime(*info.date_time).strftime("%Y-%m-%d %H:%M:%S")
        }

        try:
            # PDF
            if ext == ".pdf":
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    for page in pdf.pages:
                        img = page.to_image(resolution=200).original
                        buffered = io.BytesIO()
                        img.save(buffered, format="PNG")
                        encoded = base64.b64encode(buffered.getvalue()).decode("utf-8")
                        page_images.append(encoded)
                        all_images.append(encoded)

            # Images
            elif ext in [".png", ".jpg", ".jpeg", ".bmp", ".tiff"]:
                img = Image.open(io.BytesIO(file_bytes)).convert("RGB")
                buffered = io.BytesIO()
                img.save(buffered, format="PNG")
                encoded = base64.b64encode(buffered.getvalue()).decode("utf-8")
                page_images.append(encoded)
                all_images.append(encoded)

            # DOCX
            # elif ext == ".docx":
            #     with tempfile.TemporaryDirectory() as tmpdir:
            #         unique_id = str(uuid.uuid4())
            #         docx_path = os.path.join(tmpdir, f"{unique_id}.docx")
            #         pdf_path = os.path.join(tmpdir, f"{unique_id}.pdf")

            #         with open(docx_path, "wb") as f:
            #             f.write(file_bytes)

            #         convert(docx_path, tmpdir)

            #         if os.path.exists(pdf_path):
            #             with open(pdf_path, "rb") as pdf_file:
            #                 with pdfplumber.open(pdf_file) as pdf:
            #                     for page in pdf.pages:
            #                         img = page.to_image(resolution=200).original
            #                         buffered = io.BytesIO()
            #                         img.save(buffered, format="PNG")
            #                         encoded = base64.b64encode(buffered.getvalue()).decode("utf-8")
            #                         page_images.append(encoded)
            #                         all_images.append(encoded)
                    # else:
                    #     print(f"PDF not found after converting {filename}")

            else:
                print(f"Skipped unsupported file type: {filename}")

        except Exception as e:
            print(f"Error processing {filename}: {e}")
            continue

        if page_images:
            zip_data[filename] = {
                "metadata": metadata,
                "images": page_images
            }

    zip_ref.close()
    END = perf_counter()
    print(f"\n\n*****************************************************************\n\nExtraction complete.\n--------------------\nTotal files in zip : {total_files}\nNo of files processed : {len(list(zip_data.keys()))}\nNumber of images gathered : {len(all_images)}\nTotal time taken: {round(END-START,2)}s\n\n*****************************************************************\n\n")
    return zip_data, all_images


def files_to_images(file_paths):
    START = perf_counter()
    file_data = {}
    all_images = []

    for file_path in file_paths:
        try:
            filename = os.path.basename(file_path)
            ext = os.path.splitext(file_path)[1].lower()

            with open(file_path, "rb") as f:
                file_bytes = f.read()

            page_images = []
            metadata = {
                "file_type": ext.replace(".", "").upper(),
                "size_kb": round(os.path.getsize(file_path) / 1024, 2),
                "modified_date": datetime.fromtimestamp(os.path.getmtime(file_path)).strftime("%Y-%m-%d %H:%M:%S")
            }

            # PDF
            if ext == ".pdf":
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    for page in pdf.pages:
                        img = page.to_image(resolution=200).original
                        buffered = io.BytesIO()
                        img.save(buffered, format="PNG")
                        encoded = base64.b64encode(buffered.getvalue()).decode("utf-8")
                        page_images.append(encoded)
                        all_images.append(encoded)

            # Images
            elif ext in [".png", ".jpg", ".jpeg", ".bmp", ".tiff"]:
                img = Image.open(io.BytesIO(file_bytes)).convert("RGB")
                buffered = io.BytesIO()
                img.save(buffered, format="PNG")
                encoded = base64.b64encode(buffered.getvalue()).decode("utf-8")
                page_images.append(encoded)
                all_images.append(encoded)

            # # DOCX
            # elif ext == ".docx":
            #     with tempfile.TemporaryDirectory() as tmpdir:
            #         unique_id = str(uuid.uuid4())
            #         docx_path = os.path.join(tmpdir, f"{unique_id}.docx")
            #         pdf_path = os.path.join(tmpdir, f"{unique_id}.pdf")

            #         with open(docx_path, "wb") as f:
            #             f.write(file_bytes)

            #         convert(docx_path, tmpdir)

            #         if os.path.exists(pdf_path):
            #             with open(pdf_path, "rb") as pdf_file:
            #                 with pdfplumber.open(pdf_file) as pdf:
            #                     for page in pdf.pages:
            #                         img = page.to_image(resolution=200).original
            #                         buffered = io.BytesIO()
            #                         img.save(buffered, format="PNG")
            #                         encoded = base64.b64encode(buffered.getvalue()).decode("utf-8")
            #                         page_images.append(encoded)
            #                         all_images.append(encoded)
            #         else:
            #             print(f"PDF not found after converting {filename}")

            else:
                print(f"Skipped unsupported file type: {filename}")

            if page_images:
                file_data[filename] = {
                    "metadata": metadata,
                    "images": page_images
                }

        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            continue

    END = perf_counter()
    print(f"\n\n*****************************************************************\n\nExtraction complete.\n--------------------\nTotal files given : {len(file_paths)}\nNo of files processed : {len(list(file_data.keys()))}\nNumber of images gathered : {len(all_images)}\nTotal time taken: {round(END-START,2)}s\n\n*****************************************************************\n\n")
    return file_data, all_images


def file_processor(directory: Union[List[str], str]):
    """
    file processor
    """ 
    try:
        if isinstance(directory, list) and all(isinstance(item, str) for item in directory):
            print("MOVING THROUGH FILES PIPELINE")
            try:   
                file_data, all_images = files_to_images(directory)
                return file_data
            except Exception as e:
                print(f"ERROR OCCOURED : {e}\n")
                return None
            
        elif isinstance(directory, str):
            print("MOVING THROUGH ZIP PIPELINE")
            try:   
                file_data, all_images = zip_to_images(directory)
                return file_data
            except Exception as e:
                print(f"ERROR OCCOURED : {e}\n")
                return None
        else:
            print("ERROR OCCOURED : none of the input is passed")
            return None
    except Exception as e:
        print(f"ERROR OCCOURED : {e}\n")
        return None




# file_paths = [
#     r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\unzipped\newpdfdata\medical bill.pdf",
#     r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\unzipped\newpdfdata\payslip.pdf",
   
# ]
# file_paths1 = [
#     r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\unzipped\newpdfdata\medical bill.pdf"
  
# ]

# file_data= file_processor(r"C:\Users\2273415\OneDrive - Cognizant\Desktop\llmpoc1\datacopy.zip")
# for filename, content in file_data.items():
#     print(f"\nFile: {filename}")
#     print(f"  Size (KB)     : {content['metadata']['size_kb']}")
#     print(f"  Modified Date : {content['metadata']['modified_date']}")
#     print(f"  Number of images: {len(content['images'])}")
#     print(f"  image_list : {str(content['images'])[0:30]}")
#     print("-" * 50)
# print("#"*50,"\n\n\n")
    



# file_data=file_processor(file_paths)
# for filename, content in file_data.items():
#     print(f"\nFile: {filename}")
#     print(f"  Size (KB)     : {content['metadata']['size_kb']}")
#     print(f"  Modified Date : {content['metadata']['modified_date']}")
#     print(f"  Number of images: {len(content['images'])}")
#     print(f"  image_list : {str(content['images'])[0:30]}")
#     print("-" * 50)
# print("#"*50,"\n\n\n")    



# file_data=file_processor(file_paths1)
# for filename, content in file_data.items():
#     print(f"\nFile: {filename}")
#     print(f"  Size (KB)     : {content['metadata']['size_kb']}")
#     print(f"  Modified Date : {content['metadata']['modified_date']}")
#     print(f"  Number of images: {len(content['images'])}")
#     print(f"  image_list : {str(content['images'])[0:30]}")
#     print("-" * 50)

