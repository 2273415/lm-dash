from dotenv import load_dotenv
import os
from pydantic import BaseModel
import requests
import re
import json
from pydantic import ValidationError
from uuid import uuid4
import sqlite3
from datetime import datetime,date
try:
    from database_manage import job_insert
    from model_mapping import MODEL_MAPPING
    from zip_to_image import file_processor
except:
    from utils.database_manage import job_insert
    from utils.model_mapping import MODEL_MAPPING
    from utils.zip_to_image import file_processor
    
load_dotenv()


###################### ENVIRONMENT VARIABLE ###################
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
DEPLOYMENT_NAME = os.getenv("DEPLOYMENT_NAME")  
API_VERSION = os.getenv("API_VERSION")
##############################################################
DB_PATH = r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\docintel_v1\database\operations.db"
################################################################

class ClassificationResult(BaseModel):
    text_extracted: str
    category: str
    confidence_score: int

def extract_json(text: str):
    text = text.replace("```", "").replace("json", "")
    match = re.search(r'\{.*\}', text, re.DOTALL)
    try:
        if match:
            parsed_output = json.loads(str(match.group(0)))
            return parsed_output
    except:
        return {None: None}

def prompt_enginev1(
    system_message: str = "you are a helpful assistant",
    text_prompt: str = "",
    image_input: list[str] = []
) -> dict:
    user_content = [{"type": "text", "text": text_prompt}]
    for img in image_input[:8]:
        user_content.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/png;base64,{img}"
            }
        })
    template = {
        "messages": [
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_content}
        ],
        "temperature": 0.2,
        "max_tokens": 1000
    }
    return template

def classify_document_from_image1(encoded_images: list[str]) -> ClassificationResult:
    categories = ['Invoice', 'Receipt', 'Payslip', 'Bank Statement', 'Tax Document', 'Purchase Order', 'Quotation',
                  'Credit Note', 'Debit Note', 'Medical Bill', 'Prescription', 'Medical Certificate',
                  'Discharge Summary', 'Lab Report', 'Insurance Claim Form', 'Offer Letter', 'Appointment Letter',
                  'Experience Certificate', 'Work Permit', 'Resignation Letter', 'PF Form', 'Wage Voucher',
                  'Identification Document', 'Birth Certificate', 'Death Certificate', 'Marriage Certificate',
                  'Affidavit', 'Court Order', 'Sub-contractor Agreement', 'Work Injury Compensation Insurance',
                  'Claim Form', 'Incident Report', 'Application Form', 'Feedback Form', 'Survey Form', 'Audit Report',
                  'Inspection Report', 'Marksheet', 'Degree Certificate', 'Bonafide Certificate', 'Admission Letter',
                  'Fee Receipt', 'Delivery Note', 'Packing List', 'Shipping Label', 'Bill of Lading',
                  'Patent Document', 'Trademark Certificate', 'Copyright Registration', 'Business License',
                  'MoU', 'NDA', 'Board Resolution', 'Company Incorporation Certificate', 'Annual Report',
                  'Blueprint', 'Technical Specification Sheet', 'Bill of Materials', 'Maintenance Log',
                  'Test Report', 'Calibration Certificate', 'SOP', 'Vendor Registration Form', 'Supplier Agreement']

    prompt = f"""
You are a document processing assistant. First, extract all readable text from the image(s) provided. Then, classify the document into one of the following categories:

{categories}

Return a JSON object with:
- "text_extracted": the extracted text (string)
- "category": the best matching category (string)
- "confidence_score": an integer between 0 and 100 indicating confidence.
"""

    payload = prompt_enginev1(
        system_message="You are a helpful assistant.",
        text_prompt=prompt,
        image_input=encoded_images
    )

    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_OPENAI_API_KEY
    }
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code != 200:
        raise Exception(f"API call failed: {response.status_code} - {response.text}")

    result_json = response.json()['choices'][0]['message']['content'].strip()
    try:
        result = json.loads(result_json)
    except:
        result = extract_json(result_json)

    return ClassificationResult(
        text_extracted=result.get("text_extracted", ""),
        category=result.get("category", "Others"),
        confidence_score=result.get("confidence_score", 0)
    )

def parse_document_with_model_prompt(result_from_first_pipeline:dict)->dict:
    extracted_text=result_from_first_pipeline['text_extracted']
    category=result_from_first_pipeline['category']
    # Step 1: Get the corresponding Pydantic model
    model_class = MODEL_MAPPING.get(category)
    if not model_class:
        raise ValueError(f"No model found for category: {category}")

    # Step 2: Get the model schema to guide the prompt
    schema = model_class.schema()
    fields = schema.get("properties", {})

    # Step 3: Build a prompt using the schema
    prompt = f"""
You are a document processing assistant. Based on the following extracted text, extract structured data matching the schema for a {category} document.

Extracted Text:
{extracted_text}

Expected Fields:
{json.dumps(fields, indent=2)}

Return a JSON object with keys matching the expected fields.
"""

    # Step 4: Prepare payload for prompt engine
    payload = prompt_enginev1(
        system_message="You are a helpful assistant.",
        text_prompt=prompt,
        image_input=[]
    )

    # Step 5: Send request to Azure OpenAI
    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_OPENAI_API_KEY
    }
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code != 200:
        raise Exception(f"API call failed: {response.status_code} - {response.text}")

    result_json = response.json()['choices'][0]['message']['content'].strip()
    try:
        structured_data = json.loads(result_json)
    except json.JSONDecodeError:
        structured_data = extract_json(result_json)

    # Step 6: Validate using the Pydantic model
    try:
        model_instance = model_class(**structured_data)
    except ValidationError as e:
        raise ValueError(f"Validation failed for {category} model: {e}")

    return model_instance.dict()


def Azure_pippeline(path: str, username: str):
    file_data = file_processor(path)
    if not file_data:
        print("No data returned from file_processor.")
        return

    jobid = str(uuid4())
    now = datetime.now()
    job_creation_time = now.strftime("%H:%M:%S")
    job_creation_date = date.today()

    all_results = []

    for filename, content in file_data.items():
        document_type = str(filename).split(".")[-1]
        size_kb = content['metadata']['size_kb']
        created = content['metadata']['modified_date']
        num_images = len(content['images'])

        result = classify_document_from_image1(content['images']).model_dump()
        extracted_text_output = result['text_extracted']
        category = result['category']
        category_confidence = result['confidence_score']

        extracted_data_json = parse_document_with_model_prompt(result)

        try:
            job_insert(jobid, job_creation_date, job_creation_time, username,
                       filename, document_type, created, size_kb,
                       extracted_text_output, category, category_confidence, extracted_data_json)
        except Exception as e:
            print(f"ERROR: {e}\nRetrying with direct DB insert...")
            try:
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute('''
                    INSERT INTO jobs (
                        jobid, job_creation_date, job_creation_time, username,
                        filename, document_type, created, size_kb,
                        extracted_text_output, category, category_confidence, extracted_data_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    jobid, job_creation_date, job_creation_time, username,
                    filename, document_type, created, size_kb,
                    extracted_text_output, category, category_confidence, str(extracted_data_json)
                ))
                conn.commit()
                conn.close()
            except Exception as db_error:
                print(f"Database error: {db_error}")

        all_results.append({
            "filename": filename,
            "document_type": document_type,
            "size_kb": size_kb,
            "created": created,
            "num_images": num_images,
            "category": category,
            "confidence": category_confidence,
            "extracted_text": extracted_text_output,
            "extracted_data": extracted_data_json
        })
    print("-----------------------------------porcess completed -------------------------------")
    # return {
    #     "jobid": jobid,
    #     "username": username,
    #     "job_creation_date": str(job_creation_date),
    #     "job_creation_time": job_creation_time,
    #     "documents": all_results
    # }
###############test############


# file_paths = [
#     r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\unzipped\newpdfdata\medical bill.pdf",
#     #r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\unzipped\newpdfdata\payslip.pdf",
# ]

# #C:\\Users\\2273415\OneDrive - Cognizant\Desktop\\doc intel\\doc-stable-main\\docintelv2\\newpdfdata\\unzipped\\newpdfdata\\
# zip_path=r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\newpdfdata.zip"

# Azure_pippeline(zip_path,"ranji322002@gmail.com")

