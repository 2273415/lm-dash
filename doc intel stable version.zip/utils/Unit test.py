
from zip_to_image import file_processor
import logging


logging.basicConfig(level=logging.INFO,format='%(asctime)s - %(levelname)s - %(message)s')

def run_image_conversion_tests():
    """
    Runs unit tests for image conversion pipelines using file_processor.
    This includes:
    - ZIP file input
    - List of file paths
    - Single file path in a list
    """
    logging.info("Starting image conversion unit tests...")

    # Test 1: ZIP pipeline
    try:
        logging.info("Test 1: ZIP pipeline")
        zip_result = file_processor(r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\newpdfdata.zip")
        assert zip_result is not None, "ZIP pipeline failed"
        logging.info(f"ZIP pipeline processed {len(zip_result)} files")
    except Exception as e:
        logging.error(f" ZIP pipeline error: {e}")

    # Test 2: Multiple file paths
    file_paths = [
    r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\unzipped\newpdfdata\medical bill.pdf",
    r"C:\Users\2273415\OneDrive - Cognizant\Desktop\doc intel\doc-stable-main\docintelv2\newpdfdata\unzipped\newpdfdata\payslip.pdf",

]

    try:
        logging.info(" Test 2: Multiple file paths")
        list_result = file_processor(file_paths)
        assert list_result is not None, "File list pipeline failed"
        logging.info(f" File list pipeline processed {len(list_result)} files")
    except Exception as e:
        logging.error(f"File list pipeline error: {e}")

    # Test 3: Single file path
    try:
        logging.info(" Test 3: Single file path")
        single_result = file_processor([file_paths[0]])
        assert single_result is not None, "Single file pipeline failed"
        logging.info(f"Single file pipeline processed {len(single_result)} files")
        print(single_result)
    except Exception as e:
        logging.error(f"Single file pipeline error: {e}")

    logging.info("All image conversion tests completed.")



# run_image_conversion_tests()