# --- Pipeline logic from app.py ---
import tempfile
import shutil
from datetime import datetime
import json 
from datetime import date
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_bcrypt import Bcrypt
import sqlite3

from flask import jsonify
import os
from werkzeug.utils import secure_filename
import zipfile
import threading
def text_processor(filename: str, job_name: str, output_dir=None):
    from FileAnalyzer.FileAnalyzer import FileAnalyzer
    from FileAnalyzer.OCRProcessor import OCRProcessor
    from FileAnalyzer.DataExtractor import DataExtractor
    from FileAnalyzer.logger import close_logger_handlers
    import json
    import os
    # Use a temp dir if not provided
    if output_dir is None:
        temp_dir = tempfile.TemporaryDirectory()
        output_dir = temp_dir.name
    else:
        temp_dir = None
    # Step 1: FileAnalyzer
    analyzer = FileAnalyzer(path=filename, job_name=job_name, base_output=output_dir)
    results, job_dir = analyzer.run()

    # Step 2: OCR Post-processing
    ocr = OCRProcessor(languages=['en'], gpu=False, job_dir=job_dir, job_name=job_name+"_OCR")
    ocr.process_job_dir(job_dir)

    # Step 3: Data Extraction
    extractor = DataExtractor(job_dir=job_dir, languages=['en'], gpu=False)
    extracted_files = extractor.process_job_dir()

    # Step 4: Build structured output
    contents = {}
    for json_path in extracted_files:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        for filename_key, content in data.items():
            content.pop("pages", None)

            created_time = datetime.now().isoformat()
            size_kb = round(os.path.getsize(json_path) / 1024, 2)

            contents[filename_key] = {
                "metadata": {
                    "created": created_time,
                    "size_kb": size_kb
                },
                "extracted_data_output": content
            }

    # Close all log handlers for this job to allow temp dir cleanup
    try:
        close_logger_handlers(analyzer.logger)
    except Exception:
        pass
    # Close OCR and extractor loggers if present
    try:
        close_logger_handlers(ocr.logger)
    except Exception:
        pass
    try:
        close_logger_handlers(extractor.logger)
    except Exception:
        pass
    # Clean up temp dir if we created it
    if temp_dir is not None:
        temp_dir.cleanup()

    result = {"contents": contents}
    return result

# Helper to recursively delete a directory
def delete_job_output_dir(job_dir):
    import shutil
    if os.path.exists(job_dir):
        shutil.rmtree(job_dir, ignore_errors=True)
import json

# Helper to insert job info into jobs table
def insert_job_info(job_name, username, output_json_path, jobid, job_creation_time,job_creation_date):
    if not os.path.exists(output_json_path):
        return
    try:
        with open(output_json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    for filename, content in data.items():
        meta = content.get('metadata', {})
        extracted = content.get('extracted_data_output', {})
        created = meta.get('created')
        size_kb = meta.get('size_kb')
        extracted_text_output = extracted.get('extracted_op', {}).get('1')
        extracted_data_output = extracted.get('extracted_data_output', {}).get('1', {})
        category = extracted_data_output.get('category')
        category_confidence = extracted_data_output.get('category_confidence')
        document_type = filename.split(".")[1]
        extracted_data_json = json.dumps(extracted_data_output.get('extracted_data'))
        c.execute('''INSERT INTO jobs (jobid,job_creation_date,job_creation_time, username, filename, document_type, created, size_kb, extracted_text_output, category, category_confidence, extracted_data_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (jobid,job_creation_date,job_creation_time, username, filename, document_type, created, size_kb, extracted_text_output, category, category_confidence, extracted_data_json))
    conn.commit()
    conn.close()
    print("\n\n\n-------------------------process completed----------------------------------\n\n\n")


ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'csv', 'xlsx', 'ppt', 'pptx', 'zip'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_text_before_numbers(s):
    result = ''
    for char in s:
        if char.isdigit():
            break
        result += char
    return result

DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'database', 'users.db'))




def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(100) NOT NULL,
            accepted_terms INTEGER DEFAULT 0 NOT NULL
        )''')
    # Add jobs table with improved columns
    c.execute('''CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        jobid TEXT NOT NULL,
        Job_creation_date VARCHAR(50),
        job_creation_time VARCHAR(50),
        username VARCHAR(50),
        filename VARCHAR(255) NOT NULL,
        document_type VARCHAR(50),
        created VARCHAR(50),
        size_kb REAL,
        extracted_text_output TEXT,
        category VARCHAR(100),
        category_confidence REAL,
        extracted_data_json TEXT
    )''')
    conn.commit()
    conn.close()






app = Flask(__name__)
app.secret_key = 'mykey'
bcrypt = Bcrypt(app)



@app.route('/upload_files', methods=['POST'])
def upload_files():
    if 'files' not in request.files:
        flash('No files part', 'error')
        return redirect(url_for('index'))
    files = request.files.getlist('files')
    file_infos = []
    # ensure uploads directory
    upload_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'uploads'))
    os.makedirs(upload_dir, exist_ok=True)
    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            save_path = os.path.join(upload_dir, filename)
            try:
                file.save(save_path)
                size = os.path.getsize(save_path)
            except Exception:
                # fallback to stream size
                file.seek(0, 2)
                size = file.tell()
                file.seek(0)
            file_infos.append({'filename': filename, 'filesize': f"{size/1024:.2f} KB", 'saved_name': filename})
        # If file is a zip, extract and list its contents
        elif file and file.filename.lower().endswith('.zip'):
            try:
                zip_name = secure_filename(file.filename)
                zip_path = os.path.join(upload_dir, zip_name)
                file.save(zip_path)
                with zipfile.ZipFile(zip_path) as z:
                    for info in z.infolist():
                        if not info.is_dir():
                            # extract into upload_dir
                            try:
                                z.extract(info, path=upload_dir)
                                extracted_basename = os.path.basename(info.filename)
                                file_infos.append({'filename': extracted_basename, 'filesize': f"{info.file_size/1024:.2f} KB", 'saved_name': extracted_basename})
                            except Exception:
                                continue
                try:
                    os.remove(zip_path)
                except Exception:
                    pass
            except Exception as e:
                flash(f'Error processing zip file: {file.filename}', 'error')
                continue
    if not file_infos:
        flash('No valid files uploaded', 'error')
        return redirect(url_for('index'))
    # remember uploaded filenames in session so proceed can find them
    try:
        session['uploaded_files'] = [f['saved_name'] for f in file_infos if 'saved_name' in f]
    except Exception:
        session['uploaded_files'] = []

    # If request came from AJAX (fetch), return a fragment suitable for injection
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return render_template('uploaded_files_fragment.html', files=file_infos)



# Upload zip file route
@app.route('/upload_zip', methods=['POST'])
def upload_zip():
    zipfile_obj = request.files.get('zipfile')
    if not zipfile_obj or not zipfile_obj.filename.lower().endswith('.zip'):
        flash('Please upload a valid zip file', 'error')
        return redirect(url_for('index'))
    file_infos = []
    with zipfile.ZipFile(zipfile_obj) as z:
        for info in z.infolist():
            if not info.is_dir():
                file_infos.append({'filename': info.filename, 'filesize': f"{info.file_size/1024:.2f} KB"})
    if not file_infos:
        flash('No files found in zip', 'error')
        return redirect(url_for('index'))
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return render_template('uploaded_files_fragment.html', files=file_infos)
    return render_template('uploaded_files.html', files=file_infos)

# Proceed route: start pipeline for selected files
@app.route('/proceed', methods=['POST'])
def proceed():
    # start pipeline for selected files
    selected = request.form.getlist('selected_files')
    if not selected:
        flash('No files selected to proceed', 'error')
        return redirect(url_for('index'))

    upload_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'uploads'))
    paths = [os.path.join(upload_dir, secure_filename(name)) for name in selected]

    # Get username from session in request context BEFORE starting thread
    username = None
    if 'user_id' in session:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
        user = c.fetchone()
        conn.close()
        if user:
            username = user[0]

    def _run_pipeline(file_paths, username):
        import tempfile, os, json
        if text_processor is None:
            app.logger.error('Pipeline function not available')
            return
        import uuid
        jobid = str(uuid.uuid4())
        now=datetime.now()
        job_creation_time = now.strftime("%H:%M:%S")
        job_creation_date=date.today()
        for p in file_paths:
            try:
                job_name = os.path.splitext(os.path.basename(p))[0]
                app.logger.info(f'Starting pipeline for {p}')
                with tempfile.TemporaryDirectory() as temp_dir:
                    extracted = text_processor(p, job_name, output_dir=temp_dir)
                    print(extracted)
                    # Save extracted result to a temp file for DB insert
                    temp_json = os.path.join(temp_dir, job_name + '.json')
                    with open(temp_json, 'w', encoding='utf-8') as f:
                        json.dump(extracted['contents'], f, ensure_ascii=False, indent=2)
                    if username:
                        insert_job_info(job_name, username, temp_json, jobid, job_creation_time,job_creation_date)
                # All temp files are deleted automatically
            except Exception:
                app.logger.exception('Unexpected error during pipeline run')
    # run in background so HTTP response returns quickly
    t = threading.Thread(target=_run_pipeline, args=(paths, username), daemon=True)
    t.start()

    flash('Pipeline started for selected files', 'success')
    return redirect(url_for('index', process='completed'))



# API endpoint for programmatic file processing (single or multiple files)
@app.route('/process', methods=['POST'])
def process_endpoint():
    """
    API endpoint to process one or more uploaded files and return extracted contents as JSON.
    Accepts form files under field 'file' (single) or multiple files with the same name.
    """
    files = request.files.getlist('file') or request.files.getlist('files')
    if not files or len(files) == 0:
        return jsonify({'error': 'No files uploaded'}), 400

    upload_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'uploads'))
    os.makedirs(upload_dir, exist_ok=True)

    results = {}
    for file in files:
        if not file or file.filename == '':
            continue
        filename = secure_filename(file.filename)
        saved_path = os.path.join(upload_dir, filename)
        try:
            file.save(saved_path)
        except Exception as e:
            results[filename] = {'error': f'Failed to save uploaded file: {e}'}
            continue

        job_name = filename.rsplit('.', 1)[0]
        try:
            # Use the local text_processor (may raise)
            extracted = text_processor(saved_path, job_name)
            # text_processor returns {'contents': {...}}
            results[filename] = extracted.get('contents', extracted)
        except Exception as e:
            results[filename] = {'error': str(e)}
        finally:
            # Clean up saved file
            try:
                os.remove(saved_path)
            except Exception:
                pass

    return jsonify(results), 200


@app.route('/')
def index():
    if 'user_id' in session:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
        user = c.fetchone()
        conn.close()
        if user:
            email = user[0]
            username = email.split('@')[0] if '@' in email else email
            profile_initial = username[0].upper() if username else ''
            return render_template('home.html', username=username, email=email, profile_initial=profile_initial)
    return redirect(url_for('login'))

# ---------------- SIGNUP ----------------
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        print(username,password,confirm)
        if not username or not password:
            flash('Please provide both username and password.', 'error')
            return render_template('signup.html')

        if password != confirm:
            flash('Passwords do not match', 'error')
            return render_template('signup.html')

        hashed = bcrypt.generate_password_hash(password)

        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute(
                'INSERT INTO users (username, password, accepted_terms) VALUES (?, ?, ?)',
                (username, hashed, 0)
            )
            conn.commit()
            # verify insert
            c.execute('SELECT id FROM users WHERE username = ?', (username,))
            user_row = c.fetchone()
            conn.close()

            if not user_row:
                flash('An error occurred during signup. Please try again.', 'success')
                return render_template('signup.html')

            # set pending user in session for terms
            session['pending_user'] = username
            return redirect(url_for('terms'))

        except sqlite3.IntegrityError:
            flash('Username already exists.', 'error')
        except Exception as e:
            app.logger.error(f"Signup error: {str(e)}")
            flash('An error occurred during signup.', 'error')

    return render_template('signup.html')

# ---------------- TERMS ----------------
@app.route('/terms', methods=['GET', 'POST'])
def terms():
    username = session.get('pending_user')
    if not username:
        flash("You must sign up first before accepting terms.", "error")
        return redirect(url_for('signup'))

    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'accept':
            try:
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute('UPDATE users SET accepted_terms = 1 WHERE username = ?', (username,))
                conn.commit()
                conn.close()

                session.pop('pending_user', None)
                flash("You’ve accepted the Terms and Conditions. Please log in.", "message")
                return redirect(url_for('login'))

            except Exception as e:
                app.logger.error(f"Terms acceptance error for {username}: {str(e)}")
                flash("An error occurred while saving your acceptance.", "error")

        elif action == 'decline':
            try:
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute('DELETE FROM users WHERE username = ?', (username,))
                conn.commit()
                conn.close()

                session.pop('pending_user', None)
                flash("You declined the Terms. Please sign up again if you change your mind.", "error")
                return redirect(url_for('signup'))

            except Exception as e:
                app.logger.error(f"Decline deletion error for {username}: {str(e)}")
                flash("An error occurred while declining.", "error")

    return render_template('terms.html')

# ---------------- LOGIN ----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute('SELECT id, password, accepted_terms FROM users WHERE username = ?', (username,))
            user = c.fetchone()
            conn.close()

            if user and bcrypt.check_password_hash(user[1], password):
                accepted_terms = bool(user[2])
                if not accepted_terms:
                    # redirect to terms if not accepted
                    session['pending_user'] = username
                    flash('Please accept the Terms & Conditions before logging in.', 'warning')
                    return redirect(url_for('terms'))

                # login success
                session['user_id'] = user[0]
                return redirect(url_for('index'))

            flash('Invalid username or password.', 'error')

        except Exception as e:
            app.logger.error(f"Login error: {str(e)}")
            flash('An error occurred during login.', 'error')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

@app.route('/about')
def about():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # You can pass username/profile if you want
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()
    conn.close()
    
    profile_initial = user[0][0].upper() if user else 'U'
    
    return render_template('about.html', profile_initial=profile_initial)




@app.route("/process", methods=["GET"])
def process_tab():
    if 'user_id' not in session:
        return redirect(url_for("login"))

    # Get current user
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()
    conn.close()

    if not user:
        return redirect(url_for("login"))

    username = user[0]  # exact username stored in DB
    profile_initial = username[0].upper() if username else 'U'

    # Get search query
    search_query = request.args.get('search', '').strip()

    # Query recent jobs for this user, case-insensitive filename search
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    if search_query:
        c.execute("""
            SELECT jobid, category, filename, document_type, job_creation_time,job_creation_date
            FROM jobs
            WHERE username = ? AND filename LIKE ? COLLATE NOCASE
            ORDER BY job_creation_time DESC
        """, (username, f"%{search_query}%"))
    else:
        c.execute("""
            SELECT jobid, category, filename, document_type, job_creation_time,job_creation_date
            FROM jobs
            WHERE username = ?
            ORDER BY job_creation_time DESC
        """, (username,))
    jobs = c.fetchall()
    print(jobs)
    conn.close()

    return render_template(
        "process.html",
        profile_initial=profile_initial,
        jobs=jobs,
        search_query=search_query
    )

@app.route("/view/<jobid>")
def view_job(jobid):

    if 'user_id' not in session:
        return redirect(url_for("login"))

    # Get current user
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT username FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()
    conn.close()

    if not user:
        return redirect(url_for("login"))

    username = user[0]  # exact username stored in DB
    profile_initial = username[0].upper() if username else 'U'
    print("profile initial:\n\n\n",profile_initial)
    if 'user_id' not in session:
        return redirect(url_for("login"))

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    # Fetch job details by jobid
    c.execute("""SELECT filename, document_type, created, size_kb, extracted_text_output, 
                        category, category_confidence, extracted_data_json 
                 FROM jobs WHERE jobid = ?""", (jobid,))
    job = c.fetchone()
    conn.close()
    print("Raw JSON:", job[7])

    if not job:
        return "Job not found", 404

    # Parse JSON for table display
    extracted_data_dict = {}
    if job[7]:
        try:
            extracted_data_dict = json.loads(job[7])
        except Exception:
            extracted_data_dict = {}

    return render_template("view_job.html", job=job, extracted_data=extracted_data_dict, profile_initial=profile_initial)

@app.route("/update_job/<jobid>", methods=["POST"])
def update_job(jobid):
    if 'user_id' not in session:
        return {"error": "Unauthorized"}, 401

    # Get the edited data from the frontend
    edited_data = request.get_json()
    if not edited_data:
        return {"error": "No data provided"}, 400

    # Convert dict to JSON string
    edited_json_str = json.dumps(edited_data)

    # Update the jobs table
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "UPDATE jobs SET extracted_data_json = ? WHERE jobid = ?",
        (edited_json_str, jobid)
    )
    conn.commit()
    conn.close()

    return {"message": "Job data updated successfully!"}, 200

@app.route("/delete-account", methods=["POST"])
def delete_account():
    if 'user_id' not in session:
        return {"error": "Unauthorized"}, 401

    user_id = session['user_id']

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    try:
        # Get username first
        c.execute("SELECT username FROM users WHERE id = ?", (user_id,))
        username = c.fetchone()
        if not username:
            return {"error": "User not found"}, 404
        
        username = username[0]

        # Delete all jobs belonging to the user
        c.execute("DELETE FROM jobs WHERE username = ?", (username,))
        
        # Delete the user
        c.execute("DELETE FROM users WHERE id = ?", (user_id,))
        
        conn.commit()
        
        # Clear the session
        session.clear()
        
        return {"message": "Account deleted successfully"}, 200
    except Exception as e:
        conn.rollback()
        return {"error": str(e)}, 500
    finally:
        conn.close()

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=8000, use_reloader=False)


